ThemeOverrideTest - "Golden Glass" dialogue theme (example pack)
================================================================

WHAT THIS IS
  A worked example of retheming the QuestLines NPC dialogue window WITHOUT
  touching the QuestLines jar. It ships a single overriding asset file plus a
  small set of generated textures, and relies on Hytale's last-loaded-wins
  asset resolution (a mods/ pack loads after Core, so its copy of a shared
  asset path wins).

  Theme look: the window, title and panels are TRANSPARENT (translucent dark
  glass) and every edge / frame / button carries a GOLDEN accent (a baked
  double-line frame with corner brackets), plus golden flourishes top & bottom,
  a golden glow divider, and a golden close (X) button.

FILES
  Common/UI/Custom/questlines/DialogueTheme.ui
      The override. Core's Dialogue.ui imports this for every colour, size and
      background token, so replacing just this one file reskins the whole
      dialogue. Points all frame/button/divider/decoration backgrounds at the
      golden/ PNGs and sets warm-gold text colours. Also sets @DialogHeight /
      @DialogBottom - the window is sized a touch taller than Core's default
      (340 vs 300) to show that a theme pack controls the dialog height too.
      (Per-page WIDTH is dynamic and lives in the QuestLines PluginConfig.)

  Common/UI/Custom/questlines/golden/*.png
      The generated gold-on-glass art:
        window.png / title.png          9-slice translucent panels w/ gold frame
        button[_hover|_press|_disabled] 9-slice translucent buttons w/ gold frame
        divider.png                     golden glow vertical divider
        decoration_top|bottom.png       golden ornamental flourishes
        close[_hover|_press].png        golden close (X) button states

  _gen_golden_textures.py
      Reproducible generator for every PNG above (Python + Pillow). Re-run it
      after editing to regenerate the art:
          python _gen_golden_textures.py
      Tweak the palette / shapes at the top of the script to restyle.

HOW IT WORKS
  Core's window shell (Dialogue.ui) is hand-built so every surface - window,
  title, divider, decorations, panels, buttons, close button - reads a token
  from DialogueTheme.ui. Each *Background token accepts either a colour (with an
  optional alpha suffix for transparency) or a PatchStyle(TexturePath: ...) for
  an image. This pack supplies images with a transparent fill and gold ornament,
  and uses Border: on each PatchStyle to 9-slice the gold edges so they stay
  crisp at any size. See md/dialogue-theming.md in the QuestLines repo.

HOW TO TEST
  1. This folder is already in server/mods/. Start the server.
  2. Talk to a QuestLines quest-giver NPC to open a dialogue.
     PASS = a translucent dark window with golden frame/brackets, golden
            flourishes top & bottom, golden-bordered response buttons (brighter
            gold on hover), a golden divider when responses + text both show,
            and a golden close (X) button. NPC name is bright gold; body text
            is warm cream. The window also sits slightly taller / higher off the
            bottom than the stock dialogue (the @DialogHeight/@DialogBottom
            size override).
     FAIL = stock blue/grey opaque dialogue. Check the server console for the
            asset-pack load line mentioning "ThemeOverrideTest" and any
            duplicate-asset or .ui parse warnings.

NOTES
  - Per-response answer buttons that carry an author/server colour override are
    drawn with computed inline styling in Java (so author intent wins) and do
    NOT read this theme - that is expected. Responses with no colour override,
    the Continue / Cancel / picker buttons, the frame, title, divider,
    decorations and close button all DO come from this file.
  - Asset-only pack (no Main class). The manifest declares a hard dependency on
    net.evilcraft:QuestLines purely to guarantee this pack loads AFTER Core so
    its DialogueTheme.ui wins the path collision.

REVERT
  Delete this entire folder (server/mods/ThemeOverrideTest/) and restart.
  Nothing else is affected.
