ThemeOverrideTest - throwaway asset pack
========================================

PURPOSE
  Verifies two override paths via last-loaded-wins asset resolution:
    (A) a mods/ pack overriding a STOCK Hytale UI file, and
    (B) a mods/ pack overriding ANOTHER PLUGIN's UI file (QuestLines)
        without editing that plugin's jar.

  Files shipped:

  (A) Common/UI/Custom/Common.ui
      Verbatim copy of stock Hytale Common.ui with three color literals
      changed to garish test values:
          @ColorButtonText   #bfcdd5 -> #ff2bd6   (magenta button text)
          @DefaultLabelStyle #96a9be -> #00e5ff   (cyan default labels)
          @TitleStyle        #b4c8c9 -> #39ff14   (bright-green titles)

  (B) Common/UI/Custom/questlines/Dialogue.ui
      Verbatim copy of QuestLines' Dialogue.ui with two changes, both
      ORANGE so they read as distinct from the Common.ui changes:
          @ResponseButtonStyle Default Background #2b3542 -> #ff7700
              (orange Continue / Cancel / Picker-Cancel buttons)
          #NPCName label TextColor #ffffff -> #ff7700
              (orange NPC speaker name)

  Everything else (every @-style name, texture paths, the $C / $Sounds
  imports) is untouched, so dependent layouts still resolve. Sounds.ui
  and Common.ui imports resolve from the merged asset tree.

  LOAD ORDER: the manifest declares a hard dependency on
  net.evilcraft:QuestLines so this pack is guaranteed to load AFTER
  QuestLines - required for (B) to win the file collision. (Override of
  the stock file (A) needs no dependency: every mods/ pack already loads
  after stock Hytale.)

HOW TO TEST
  1. This folder is already in server/mods/. Start the server.
  2. (A) Open any titled menu - /journal, a vanilla Hytale menu:
         PASS = green titles, magenta button labels, cyan labels, in
         BOTH QuestLines and vanilla screens.
  3. (B) Talk to a QuestLines quest-giver NPC to open a dialogue:
         PASS = the NPC speaker name and the Continue/Cancel buttons
         are ORANGE. (The per-response answer buttons stay their normal
         color - those are colored in Java, not from this file; see
         NOTE.)
  4. FAIL = colors unchanged. Check the server console for asset-pack
     load lines mentioning "ThemeOverrideTest" and any duplicate-asset
     or parse warnings.

REVERT
  Delete this entire folder (server/mods/ThemeOverrideTest/) and
  restart. Nothing else is affected; it is git-ignored.

NOTES
  - Per-response answer buttons in dialogue are tinted in Java
    (DialogueUI builds them from response_default_color), NOT from
    @ResponseButtonStyle in this file. So overriding Dialogue.ui will
    NOT recolor those - that is expected, and is exactly why the wiki
    lists those colors under "Values That Require a Source Build."
    The Continue/Cancel buttons and the NPCName label DO come from this
    file, which is why they turn orange.
  - This is an asset-only pack (no Main class). If the server refuses
    to load it for lack of a main entrypoint, the override approach
    still works - just ship the files inside an existing plugin's asset
    pack instead.
